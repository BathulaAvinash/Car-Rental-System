import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-3LDTFWFR.js";
import "./chunk-32NQEHB4.js";
import "./chunk-IV3KQ6CZ.js";
import "./chunk-UCKDGZ4V.js";
import "./chunk-XU6KJFTU.js";
import "./chunk-NKASZPQJ.js";
import "./chunk-BM37EVK5.js";
import "./chunk-F5VXPRTG.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
