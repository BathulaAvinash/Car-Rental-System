import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-BMPNON4C.js";
import "./chunk-F5VXPRTG.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
