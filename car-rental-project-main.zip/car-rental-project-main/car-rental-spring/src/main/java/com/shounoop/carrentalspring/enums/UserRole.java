package com.shounoop.carrentalspring.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
